# O Observador (Minecraft 1.12.2 / Forge 14.23.5.2860)

Uma coisa mora no seu mundo. Ela só olha. Até a 3ª noite.

## Como gerar o .jar
**Pelo celular (GitHub Actions):**
1. Cria um repositório novo no GitHub.
2. Sobe o `observador-mod.zip` na raiz (Add file → Upload files).
3. Add file → Create new file → nome `.github/workflows/build.yml` → cola o conteúdo do `build.yml`.
4. Aba *Actions* → *build-mod* → quando ficar verde, baixa o artefato `observador-jar`. Dentro está o `.jar`.

**No PC:** JDK 8 + Gradle 4.9 → `gradle setupCIWorkspace build` → jar em `build/libs/`.

Instala o Forge 1.12.2 (14.23.5.2860) e joga o `.jar` na pasta `mods`.

## O que acontece
| Quando | O que rola |
|---|---|
| Noites 1–2 (fase 0) | Só o Observador: aparece longe (32–46 blocos), parado, te encarando. Perto demais ou encarou demais → some. |
| Noite 2+, **à noite, em casa** | O Observador aparece 10–15 blocos fora da casa, com linha de visão pra você, fica **5 segundos** e some. "Casa" = teto + cama de respawn perto, ou 3+ móveis (cama, bancada, fornalha, baú, estante…). |
| Noite 3+ (fase 1) | Folhas somem, tochas apagam, vultos nas costas, sons, névoa fechada com vinheta, chuva. Depois de um susto ele pode **falar seu nome no chat**. Em **caverna profunda** (abaixo de y=36) pode abrir a **sala dos fundos**. |
| Noite 5+ (fase 2) | Grama morre, tocha vira redstone, trovão. Entra o **APAGAO** (raro). |
| Noite 7+ (fase 3) | Vultos colados, névoa pesada, sustos em sequência. |
| **3 h de jogatina** (qualquer fase) | A cada 4–9 min um animal perto de você morre (de preferência quando você não está olhando). Inclui pets, dá pra poupar em `Config.MATAR_PETS`. |

### Apagão (raro, a partir da noite 5)
Escuridão total por 3 minutos (ou até você morrer). Todas as tochas por perto apagam e as **Sombrinhas** (pequenas, olhos vermelhos) saem andando atrás de você; às vezes batem (1 coração). Se você bater numa, vira fumaça. Cooldown mínimo de 20 min.

### Sala dos fundos
Um salão amarelado de corredores, carpete marrom escuro, manchas de sangue, quase sem luz, ligado ao seu túnel por uma passagem nova. O **Eco** mora lá: fica te olhando e copia seus movimentos espelhado, com um atraso de 0,5 s (anda, agacha, bate). Não dá pra encostar nele. Só constrói em rocha natural, nunca em cima de base, mina, água ou lava.

## Comandos de teste (cheats/op)
`/observador status` · `noite N` · `observador` · `vulto` · `tochas` · `som` · `nome` · `casa` · `apagao [parar]` · `sala` · `horas N` · `matar`

## Mexer nos números
Tudo em `Config.java`. Novos sustos: `Diretor.dispararEvento()`. Mudanças no mundo: `Corrupcao.java`.

## Notas
- O Observador, o Eco e as Sombrinhas não são salvos no mundo (recarregou, somem; o Eco volta quando você chega na sala).
- O tempo de jogatina e as salas criadas ficam salvos no jogador (sobrevivem a morte e a relogar).
- A fase é calculada pela hora do mundo, então dormir pra pular a noite também conta.
