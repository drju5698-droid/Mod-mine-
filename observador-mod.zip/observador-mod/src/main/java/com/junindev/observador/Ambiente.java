package com.junindev.observador;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;

/** Controla o que o CLIENTE de cada jogador mostra (nevoa/escuridao). So manda pacote quando muda. */
public final class Ambiente {
    private Ambiente() {}

    private static final Map<UUID, Integer> ULTIMO = new HashMap<UUID, Integer>();

    public static void definir(EntityPlayer p, int estado) {
        if (!(p instanceof EntityPlayerMP)) return;
        Integer antes = ULTIMO.get(p.getUniqueID());
        if (antes != null && antes.intValue() == estado) return;
        ULTIMO.put(p.getUniqueID(), estado);
        Rede.CANAL.sendTo(new PacketAmbiente(estado), (EntityPlayerMP) p);
    }

    /** Manda mesmo que ache que ja esta igual (usado no login). */
    public static void forcar(EntityPlayer p, int estado) {
        ULTIMO.remove(p.getUniqueID());
        definir(p, estado);
    }

    public static void esquecer(UUID id) {
        ULTIMO.remove(id);
    }

    public static void limpar() {
        ULTIMO.clear();
    }
}
