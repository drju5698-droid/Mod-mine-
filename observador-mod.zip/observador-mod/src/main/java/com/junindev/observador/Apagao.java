package com.junindev.observador;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

/**
 * Evento raro: ESCURIDAO TOTAL por 3 minutos (ou ate o jogador morrer).
 * O cliente fecha a nevoa em preto (estado 1) e as Sombrinhas saem andando por ai, as vezes batendo.
 */
public final class Apagao {
    private Apagao() {}

    private static final Map<UUID, Long> FIM = new HashMap<UUID, Long>();
    private static final Map<UUID, Long> LIBERA = new HashMap<UUID, Long>();

    public static boolean ativo(EntityPlayer p) {
        return FIM.containsKey(p.getUniqueID());
    }

    public static boolean podeIniciar(EntityPlayer p, long agora) {
        if (ativo(p)) return false;
        Long lib = LIBERA.get(p.getUniqueID());
        return lib == null || agora >= lib.longValue();
    }

    public static void iniciar(EntityPlayer p) {
        long agora = p.world.getTotalWorldTime();
        UUID id = p.getUniqueID();
        FIM.put(id, agora + Config.APAGAO_DURACAO);
        LIBERA.put(id, agora + Config.APAGAO_DURACAO + Config.APAGAO_COOLDOWN);

        Ambiente.definir(p, 1);
        Corrupcao.apagarTochas(p, 1, 999); // todas as tochas em volta apagam de uma vez
        Sustos.tocarEm(p, SoundEvents.ENTITY_WITHER_AMBIENT, p.posX, p.posY + 4.0D, p.posZ, 0.7F, 0.5F);
        for (int i = 0; i < 4; i++) gerarSombra(p);
    }

    /** Chamado de 10 em 10 ticks enquanto o apagao esta ativo. */
    public static void tick(EntityPlayer p, long agora) {
        Long fim = FIM.get(p.getUniqueID());
        if (fim == null) return;

        if (p.isDead || p.getHealth() <= 0.0F) {
            terminar(p, false);
            return;
        }
        if (agora >= fim.longValue()) {
            terminar(p, true);
            return;
        }

        Random r = p.getRNG();
        if (contar(p) < Config.SOMBRAS_MAX && r.nextInt(100) < 35) gerarSombra(p);
        if (r.nextInt(100) < 3) Sustos.somPerturbador(p, 3);
    }

    public static void terminar(EntityPlayer p, boolean fala) {
        FIM.remove(p.getUniqueID());
        World w = p.world;
        for (EntitySombra s : w.getEntitiesWithinAABB(EntitySombra.class, p.getEntityBoundingBox().grow(120.0D))) {
            s.dissipar();
        }
        Ambiente.definir(p, 0);
        if (fala && !p.isDead) Sustos.chamarNome(p, 100);
    }

    public static void limpar() {
        FIM.clear();
        LIBERA.clear();
    }

    private static int contar(EntityPlayer p) {
        return p.world.getEntitiesWithinAABB(EntitySombra.class, p.getEntityBoundingBox().grow(40.0D)).size();
    }

    private static boolean gerarSombra(EntityPlayer p) {
        World w = p.world;
        Random r = p.getRNG();
        for (int t = 0; t < 10; t++) {
            double ang = r.nextDouble() * Math.PI * 2.0D;
            double d = 7 + r.nextInt(9);
            int x = MathHelper.floor(p.posX + Math.cos(ang) * d);
            int z = MathHelper.floor(p.posZ + Math.sin(ang) * d);
            BlockPos chao = Util.acharChao(w, x, z, MathHelper.floor(p.posY), 4);
            if (chao == null) continue;

            EntitySombra s = new EntitySombra(w);
            s.setLocationAndAngles(x + 0.5D, chao.getY(), z + 0.5D, r.nextFloat() * 360.0F, 0.0F);
            w.spawnEntity(s);
            return true;
        }
        return false;
    }
}
