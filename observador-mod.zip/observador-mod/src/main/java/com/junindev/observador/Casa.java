package com.junindev.observador;

import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Descobre se o jogador esta "em casa". */
public final class Casa {
    private Casa() {}

    /**
     * Em casa = tem teto em cima E (a cama de respawn esta por perto OU tem 3+ "moveis" em volta:
     * cama, bancada, fornalha, bau, mesa de encantamento, estante).
     * TODO: reconhecer mais coisas (porta, janela de vidro, placa).
     */
    public static boolean estaEmCasa(EntityPlayer p) {
        World w = p.world;
        BlockPos c = p.getPosition();
        if (w.canSeeSky(c)) return false;

        BlockPos cama = p.getBedLocation();
        if (cama != null) {
            int dx = cama.getX() - c.getX();
            int dz = cama.getZ() - c.getZ();
            int dy = cama.getY() - c.getY();
            if (dx * dx + dz * dz <= 14 * 14 && Math.abs(dy) <= 6) return true;
        }

        int moveis = 0;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int dx = -6; dx <= 6; dx++) {
            for (int dy = -2; dy <= 3; dy++) {
                for (int dz = -6; dz <= 6; dz++) {
                    int y = c.getY() + dy;
                    if (y < 1 || y > 254) continue;
                    m.setPos(c.getX() + dx, y, c.getZ() + dz);
                    Block b = w.getBlockState(m).getBlock();
                    if (b == Blocks.BED || b == Blocks.CRAFTING_TABLE || b == Blocks.FURNACE || b == Blocks.LIT_FURNACE
                            || b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST || b == Blocks.ENCHANTING_TABLE
                            || b == Blocks.BOOKSHELF) {
                        moveis++;
                        if (moveis >= 3) return true;
                    }
                }
            }
        }
        return false;
    }
}
