package com.junindev.observador;

import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.world.World;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

/**
 * Atmosfera no cliente: nevoa fechada que "respira", cor de nevoa suja (esverdeada/avermelhada),
 * vinheta escura nas bordas, escuridao total no apagao e clima amarelado/doentio na sala dos fundos.
 * Estado vem do servidor: ClienteEstado.estado (0 normal, 1 apagao, 2 sala).
 */
@Mod.EventBusSubscriber(modid = ObservadorMod.MODID, value = Side.CLIENT)
public final class ClienteAmbiente {
    private ClienteAmbiente() {}

    private static World mundoOverworld() {
        World w = Minecraft.getMinecraft().world;
        if (w == null) {
            ClienteEstado.estado = 0; // saiu do mundo: zera
            return null;
        }
        return w.provider.getDimension() == 0 ? w : null;
    }

    @SubscribeEvent
    public static void aoDensidadeNevoa(EntityViewRenderEvent.FogDensity e) {
        World w = mundoOverworld();
        if (w == null) return;
        if (e.getState().getMaterial() != Material.AIR) return; // nao mexe na nevoa de agua/lava

        int estado = ClienteEstado.estado;
        int fase = Fase.de(w);
        float densidade;
        if (estado == 1) {
            densidade = Config.NEVOA_APAGAO;
        } else if (estado == 2) {
            densidade = Config.NEVOA_SALA;
        } else if (fase > 0) {
            densidade = Config.NEVOA[fase] * (Fase.ehNoite(w) ? 1.0F : 0.65F);
        } else {
            return;
        }

        float pulso = 1.0F + 0.10F * (float) Math.sin((w.getTotalWorldTime() + e.getRenderPartialTicks()) / 45.0D);
        GlStateManager.setFog(GlStateManager.FogMode.EXP);
        e.setDensity(densidade * pulso);
        e.setCanceled(true);
    }

    @SubscribeEvent
    public static void aoCorNevoa(EntityViewRenderEvent.FogColors e) {
        World w = mundoOverworld();
        if (w == null) return;

        int estado = ClienteEstado.estado;
        if (estado == 1) { // preto absoluto
            e.setRed(0.0F);
            e.setGreen(0.0F);
            e.setBlue(0.0F);
            return;
        }
        if (estado == 2) { // sala dos fundos: amarelo-sujo
            e.setRed(0.13F);
            e.setGreen(0.11F);
            e.setBlue(0.035F);
            return;
        }

        int fase = Fase.de(w);
        if (fase <= 0) return;
        float f = fase == 1 ? 0.55F : (fase == 2 ? 0.40F : 0.28F);
        e.setRed(e.getRed() * f + (fase >= 3 ? 0.05F : 0.0F)); // fase 3: um fiapo de vermelho
        e.setGreen(e.getGreen() * f + 0.012F);                  // esverdeado, igual nas referencias
        e.setBlue(e.getBlue() * f);
    }

    /** Vinheta: escurece as bordas da tela. Mais forte a cada fase; no apagao a tela toda fica escura. */
    @SubscribeEvent
    public static void aoDesenharHud(RenderGameOverlayEvent.Pre e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        World w = mundoOverworld();
        if (w == null) return;

        int estado = ClienteEstado.estado;
        int fase = Fase.de(w);
        int borda;
        int fundo = 0;
        int rgb = 0x000000;
        if (estado == 1) {
            borda = 0xC0;
            fundo = 0x58;
        } else if (estado == 2) {
            borda = 0x70;
            rgb = 0x100C00;
        } else if (fase >= 1) {
            borda = fase == 1 ? 0x40 : (fase == 2 ? 0x58 : 0x70);
            if (fase >= 3) rgb = 0x180000;
        } else {
            return;
        }

        int largura = e.getResolution().getScaledWidth();
        int altura = e.getResolution().getScaledHeight();

        if (fundo > 0) Gui.drawRect(0, 0, largura, altura, (fundo << 24) | rgb);

        int camadas = 8;
        int passo = Math.max(2, Math.min(largura, altura) / (camadas * 3));
        for (int i = 0; i < camadas; i++) {
            int alfa = borda * (camadas - i) / camadas;
            int cor = (alfa << 24) | rgb;
            int ini = i * passo;
            int fim = ini + passo;
            Gui.drawRect(ini, ini, largura - ini, fim, cor);                       // topo
            Gui.drawRect(ini, altura - fim, largura - ini, altura - ini, cor);     // base
            Gui.drawRect(ini, fim, fim, altura - fim, cor);                        // esquerda
            Gui.drawRect(largura - fim, fim, largura - ini, altura - fim, cor);   // direita
        }
    }
}
