package com.junindev.observador;

/** Ultimo estado recebido do servidor. Classe simples (sem codigo de cliente) pra poder ser lida de qualquer lado. */
public final class ClienteEstado {
    private ClienteEstado() {}

    public static volatile int estado = 0;
}
