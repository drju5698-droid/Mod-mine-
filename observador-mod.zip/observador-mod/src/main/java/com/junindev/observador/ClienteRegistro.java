package com.junindev.observador;

import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(modid = ObservadorMod.MODID, value = Side.CLIENT)
public final class ClienteRegistro {
    private ClienteRegistro() {}

    @SubscribeEvent
    public static void aoRegistrarModelos(ModelRegistryEvent e) {
        RenderingRegistry.registerEntityRenderingHandler(EntityObservador.class, RenderObservador::new);
        RenderingRegistry.registerEntityRenderingHandler(EntitySombra.class,
                manager -> new RenderSombra<EntitySombra>(manager, false, 0.55F));
        RenderingRegistry.registerEntityRenderingHandler(EntityEco.class,
                manager -> new RenderSombra<EntityEco>(manager, true, 0.62F));
    }
}
