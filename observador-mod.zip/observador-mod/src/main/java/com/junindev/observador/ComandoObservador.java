package com.junindev.observador;

import java.util.List;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

/** Comando de teste (precisa de cheats / op). */
public class ComandoObservador extends CommandBase {

    private static final String[] SUBS = {
        "status", "noite", "observador", "vulto", "tochas", "som", "nome", "casa", "apagao", "sala", "horas", "matar"
    };

    @Override
    public String getName() {
        return "observador";
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "/observador <status | noite N | observador | vulto | tochas | som | nome | casa | apagao [parar] | sala | horas N | matar>";
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 2;
    }

    @Override
    public List<String> getTabCompletions(MinecraftServer server, ICommandSender sender, String[] args, BlockPos pos) {
        if (args.length == 1) {
            return getListOfStringsMatchingLastWord(args, SUBS);
        }
        return super.getTabCompletions(server, sender, args, pos);
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (args.length == 0) throw new WrongUsageException(getUsage(sender));

        EntityPlayerMP p = getCommandSenderAsPlayer(sender);
        World w = p.world;
        int fase = Fase.de(w);
        int faseTeste = Math.max(1, fase);
        String sub = args[0].toLowerCase();

        if (sub.equals("status")) {
            long horas10 = Dados.tempo(p) / 7200L; // decimos de hora
            msg(sender, "Noite " + Fase.noiteAtual(w) + " | fase " + fase + (Fase.ehNoite(w) ? " | noite agora" : " | dia agora")
                    + " | jogatina " + (horas10 / 10.0D) + " h | salas " + Dados.salas(p).size()
                    + " | apagao " + (Apagao.ativo(p) ? "ATIVO" : "off"));
        } else if (sub.equals("noite")) {
            if (args.length < 2) throw new WrongUsageException("/observador noite <1-30>");
            int n = parseInt(args[1], 1, 30);
            server.getWorld(0).setWorldTime((n - 1L) * 24000L + 13000L);
            msg(sender, "Pulando pro comeco da noite " + n + ". Boa sorte.");
        } else if (sub.equals("observador")) {
            if (!Sustos.observador(p)) msg(sender, "Nao achei lugar bom. Vai pra um campo aberto, ao ar livre.");
        } else if (sub.equals("vulto")) {
            if (!Sustos.vulto(p, faseTeste)) msg(sender, "Nao achei lugar pro vulto (ou ja tem um por perto).");
        } else if (sub.equals("tochas")) {
            int n = Corrupcao.apagarTochas(p, faseTeste);
            msg(sender, n + " tocha(s) apagada(s).");
        } else if (sub.equals("som")) {
            Sustos.somPerturbador(p, faseTeste);
        } else if (sub.equals("nome")) {
            Sustos.chamarNomeForcado(p);
        } else if (sub.equals("casa")) {
            if (!Sustos.observadorCasa(p)) msg(sender, "Nao achei ponto la fora com visao pra voce (precisa de janela/porta aberta).");
        } else if (sub.equals("apagao")) {
            if (args.length > 1 && args[1].equalsIgnoreCase("parar")) {
                Apagao.terminar(p, false);
                msg(sender, "Apagao encerrado.");
            } else {
                if (Apagao.ativo(p)) Apagao.terminar(p, false);
                Apagao.iniciar(p);
            }
        } else if (sub.equals("sala")) {
            if (SalaFundos.tentarCriar(p) == null) {
                msg(sender, "Nao deu: precisa estar no subsolo (y 9 a " + Config.SALA_Y_MAX + "), em rocha natural, sem base/agua/lava por perto.");
            }
        } else if (sub.equals("horas")) {
            if (args.length < 2) throw new WrongUsageException("/observador horas <0-1000>");
            int h = parseInt(args[1], 0, 1000);
            Dados.definirTempo(p, h * 72000L);
            msg(sender, "Jogatina ajustada pra " + h + " h.");
        } else if (sub.equals("matar")) {
            if (!Corrupcao.matarAnimal(p)) msg(sender, "Sem animal por perto (ou voce esta olhando pra todos).");
        } else {
            throw new WrongUsageException(getUsage(sender));
        }
    }

    private static void msg(ICommandSender s, String texto) {
        s.sendMessage(new TextComponentString(texto));
    }
}
