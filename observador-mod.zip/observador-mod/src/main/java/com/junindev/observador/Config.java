package com.junindev.observador;

/**
 * Botoes do mod. Mexeu aqui, recompila e pronto.
 * TODO: virar arquivo .cfg do Forge se quiser mexer sem recompilar.
 */
public final class Config {
    private Config() {}

    // ---- quando as coisas comecam (contado em noites) ----
    public static final int NOITE_DESPERTAR = 3; // fase 1: comeca a mexer no mundo
    public static final int NOITE_FASE_2 = 5;    // fase 2: grama morre, tocha vira redstone, trovao, apagao
    public static final int NOITE_FASE_3 = 7;    // fase 3: vultos coladinhos, eventos em sequencia

    // ---- o Observador (o que olha de longe) ----
    public static final int OBS_DIST_MIN = 32;       // distancia minima que ele aparece
    public static final int OBS_DIST_MAX = 46;       // distancia maxima
    public static final int OBS_SUMIR_PERTO = 16;    // se voce chegar mais perto que isso, ele some
    public static final int OBS_OLHAR_MAX = 20 * 4;  // ticks encarando ate ele sumir

    // ---- corrosao do mundo ----
    public static final boolean FOLHAS_SOMEM = true;  // fase 1+
    public static final boolean GRAMA_MORRE = true;   // fase 2+ (grama vira terra seca, mato some)
    public static final int RAIO_CORROSAO = 40;       // raio em volta do jogador

    // ---- tochas ----
    public static final boolean TOCHAS_APAGAM = true;
    public static final boolean TOCHA_DROPA_ITEM = false; // true = a tocha cai como item em vez de sumir
    public static final int RAIO_TOCHAS = 18;
    public static final int TOCHAS_POR_VEZ = 3;           // +1 por fase

    // ---- clima ----
    public static final boolean CLIMA_PESADO = true;      // chuva/trovao forcados

    // densidade da nevoa por fase (indice = fase). Maior = mais fechado.
    public static final float[] NEVOA = { 0.0F, 0.010F, 0.016F, 0.024F };

    // ---- ele fala seu nome no chat ----
    public static final String NOME_NO_CHAT = "Observador";
    public static final int CHAT_COOLDOWN = 20 * 60 * 3;  // no minimo 3 min entre uma fala e outra

    // ---- animais morrem depois de X tempo de jogatina ----
    public static final long JOGATINA_PARA_MATAR = 20L * 60L * 60L * 3L; // 3 horas jogadas (em ticks)
    public static final boolean MATAR_PETS = true;        // false = poupa os animais domesticados (cachorro/gato/cavalo seu)
    public static final int RAIO_ANIMAIS = 48;
    public static final int ANIMAL_INTERVALO_MIN = 240;   // segundos entre uma morte e outra
    public static final int ANIMAL_INTERVALO_MAX = 540;

    // ---- apagao: escuridao total + sombrinhas ----
    public static final int APAGAO_CHANCE = 4;               // % por evento (fase 2+). Baixo = raro
    public static final int APAGAO_DURACAO = 20 * 60 * 3;    // 3 minutos
    public static final int APAGAO_COOLDOWN = 20 * 60 * 20;  // minimo 20 min entre apagoes
    public static final int SOMBRAS_MAX = 9;                 // quantas sombrinhas ao mesmo tempo
    public static final float SOMBRA_DANO = 2.0F;            // 2 = um coracao
    public static final int SOMBRA_CHANCE_BATER = 40;        // % de a pancada realmente acertar
    public static final float NEVOA_APAGAO = 0.55F;

    // ---- observador na janela de casa (so a noite) ----
    public static final int CASA_NOITE_MIN = 2;   // a partir de qual noite ele comeca a visitar sua casa
    public static final int CASA_DIST_MIN = 10;
    public static final int CASA_DIST_MAX = 15;
    public static final int CASA_DURACAO = 20 * 5; // 5 segundos

    // ---- sala dos fundos (backrooms) em caverna profunda ----
    public static final int SALA_Y_MAX = 36;                 // so abaixo dessa altura
    public static final int SALA_CHANCE = 12;                // % por evento (fase 1+, jogador no subsolo)
    public static final int SALA_COOLDOWN = 20 * 60 * 15;    // 15 min entre salas
    public static final int SALA_MAX_POR_JOGADOR = 3;
    public static final int ECO_ATRASO = 10;                 // ticks de atraso ao copiar seus movimentos
    public static final float NEVOA_SALA = 0.075F;
}
