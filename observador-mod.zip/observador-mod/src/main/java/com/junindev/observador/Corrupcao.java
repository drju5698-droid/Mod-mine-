package com.junindev.observador;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.BlockDirt;
import net.minecraft.block.BlockFlower;
import net.minecraft.block.BlockLeaves;
import net.minecraft.block.BlockTallGrass;
import net.minecraft.block.BlockTorch;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.storage.WorldInfo;

/** Mexe no mundo: folhas somem, grama morre, tochas apagam, o tempo fecha. */
public final class Corrupcao {
    private Corrupcao() {}

    /** Roda de tempos em tempos em volta do jogador. Faz uma "amostragem" de colunas: o mundo morre aos poucos. */
    public static void corroer(EntityPlayer p, int fase) {
        World w = p.world;
        Random r = p.getRNG();
        int raio = Config.RAIO_CORROSAO;
        int amostras = 5 + fase * 5;

        for (int i = 0; i < amostras; i++) {
            int x = MathHelper.floor(p.posX) + r.nextInt(raio * 2 + 1) - raio;
            int z = MathHelper.floor(p.posZ) + r.nextInt(raio * 2 + 1) - raio;
            if (!w.isBlockLoaded(new BlockPos(x, 64, z))) continue;

            int topo = w.getHeight(x, z);
            if (Config.FOLHAS_SOMEM) tirarFolhas(w, x, z, topo);
            if (fase >= 2 && Config.GRAMA_MORRE) matarGrama(w, x, z, topo, r);
        }
    }

    private static void tirarFolhas(World w, int x, int z, int topo) {
        for (int y = topo; y > topo - 16 && y > 0; y--) {
            BlockPos pos = new BlockPos(x, y, z);
            if (w.getBlockState(pos).getBlock() instanceof BlockLeaves) {
                w.setBlockState(pos, Blocks.AIR.getDefaultState(), 2);
            }
        }
    }

    private static void matarGrama(World w, int x, int z, int topo, Random r) {
        BlockPos planta = new BlockPos(x, topo, z);
        BlockPos chao = planta.down();

        Block b = w.getBlockState(planta).getBlock();
        if (b instanceof BlockTallGrass || b instanceof BlockFlower) {
            w.setBlockState(planta, Blocks.AIR.getDefaultState(), 2);
        }
        if (w.getBlockState(chao).getBlock() == Blocks.GRASS && r.nextInt(3) == 0) {
            // terra "grossa" nao volta a virar grama sozinha
            w.setBlockState(chao, Blocks.DIRT.getDefaultState()
                    .withProperty(BlockDirt.VARIANT, BlockDirt.DirtType.COARSE_DIRT), 2);
        }
    }

    /** Apaga tochas perto do jogador. Na fase 2+ algumas viram tocha de redstone (luz vermelha, bem sinistra). */
    public static int apagarTochas(EntityPlayer p, int fase) {
        return apagarTochas(p, fase, Config.TOCHAS_POR_VEZ + fase);
    }

    /** Igual ao de cima, mas voce escolhe o maximo de tochas (o apagao usa 999 = todas). */
    public static int apagarTochas(EntityPlayer p, int fase, int maximo) {
        World w = p.world;
        Random r = p.getRNG();
        BlockPos c = p.getPosition();
        int raio = Config.RAIO_TOCHAS;
        int vert = 8;

        BlockPos de = new BlockPos(c.getX() - raio, Math.max(1, c.getY() - vert), c.getZ() - raio);
        BlockPos ate = new BlockPos(c.getX() + raio, Math.min(254, c.getY() + vert), c.getZ() + raio);
        if (!w.isAreaLoaded(de, ate)) return 0;

        List<BlockPos> achadas = new ArrayList<BlockPos>();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int x = de.getX(); x <= ate.getX(); x++) {
            for (int z = de.getZ(); z <= ate.getZ(); z++) {
                for (int y = de.getY(); y <= ate.getY(); y++) {
                    m.setPos(x, y, z);
                    if (w.getBlockState(m).getBlock() == Blocks.TORCH) {
                        achadas.add(m.toImmutable());
                    }
                }
            }
        }
        if (achadas.isEmpty()) return 0;

        Collections.shuffle(achadas, r);
        int quantas = Math.min(achadas.size(), maximo);

        for (int i = 0; i < quantas; i++) {
            BlockPos pos = achadas.get(i);
            IBlockState s = w.getBlockState(pos);
            boolean vermelha = fase >= 2 && r.nextInt(100) < 30;

            if (vermelha) {
                w.setBlockState(pos, Blocks.REDSTONE_TORCH.getDefaultState()
                        .withProperty(BlockTorch.FACING, s.getValue(BlockTorch.FACING)), 3);
            } else {
                w.setBlockToAir(pos);
                if (Config.TOCHA_DROPA_ITEM) {
                    Block.spawnAsEntity(w, pos, new ItemStack(Blocks.TORCH));
                }
            }
            w.playSound(null, pos, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS,
                    0.5F, 2.0F + r.nextFloat() * 0.4F);
            if (w instanceof WorldServer) {
                ((WorldServer) w).spawnParticle(EnumParticleTypes.SMOKE_NORMAL,
                        pos.getX() + 0.5D, pos.getY() + 0.7D, pos.getZ() + 0.5D, 6, 0.1D, 0.1D, 0.1D, 0.02D);
            }
        }
        return quantas;
    }

    /**
     * Mata um animal perto do jogador (de preferencia quando ele NAO esta olhando).
     * Retorna false se nao havia nenhum candidato.
     */
    public static boolean matarAnimal(EntityPlayer p) {
        World w = p.world;
        Random r = p.getRNG();

        List<EntityAnimal> candidatos = new ArrayList<EntityAnimal>();
        List<EntityAnimal> todos = w.getEntitiesWithinAABB(EntityAnimal.class, p.getEntityBoundingBox().grow(Config.RAIO_ANIMAIS));
        for (EntityAnimal a : todos) {
            if (a.isDead) continue;
            if (!Config.MATAR_PETS && a instanceof EntityTameable && ((EntityTameable) a).isTamed()) continue;
            if (Util.estaOlhando(p, a, 0.5D)) continue; // espera voce desviar o olhar
            candidatos.add(a);
        }
        if (candidatos.isEmpty()) return false;

        EntityAnimal alvo = candidatos.get(r.nextInt(candidatos.size()));
        if (w instanceof WorldServer) {
            ((WorldServer) w).spawnParticle(EnumParticleTypes.BLOCK_CRACK,
                    alvo.posX, alvo.posY + 0.5D, alvo.posZ, 30, 0.3D, 0.3D, 0.3D, 0.05D,
                    Block.getStateId(Blocks.REDSTONE_BLOCK.getDefaultState()));
        }
        alvo.attackEntityFrom(DamageSource.OUT_OF_WORLD, Float.MAX_VALUE);
        return true;
    }

    /** Forca chuva (e trovao a partir da fase 2). */
    public static void climaPesado(WorldServer w, int fase) {
        WorldInfo info = w.getWorldInfo();
        Random r = w.rand;
        if (!info.isRaining() && r.nextInt(4) == 0) {
            info.setRaining(true);
            info.setRainTime(6000 + r.nextInt(6000));
        }
        if (fase >= 2 && info.isRaining() && !info.isThundering() && r.nextInt(3) == 0) {
            info.setThundering(true);
            info.setThunderTime(3000 + r.nextInt(3000));
        }
    }
}
