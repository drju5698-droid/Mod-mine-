package com.junindev.observador;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;

/** Dados salvos DENTRO do jogador (sobrevivem a morte e a relogar): tempo de jogatina e salas criadas. */
public final class Dados {
    private Dados() {}

    private static final String TEMPO = "observador_ticks";
    private static final String SALAS = "observador_salas";

    private static NBTTagCompound raiz(EntityPlayer p) {
        NBTTagCompound dados = p.getEntityData();
        if (!dados.hasKey(EntityPlayer.PERSISTED_NBT_TAG, 10)) {
            dados.setTag(EntityPlayer.PERSISTED_NBT_TAG, new NBTTagCompound());
        }
        return dados.getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG);
    }

    // ---- tempo de jogatina (ticks) ----
    public static long tempo(EntityPlayer p) {
        return raiz(p).getLong(TEMPO);
    }

    public static void definirTempo(EntityPlayer p, long ticks) {
        raiz(p).setLong(TEMPO, ticks);
    }

    public static long somarTick(EntityPlayer p) {
        NBTTagCompound r = raiz(p);
        long t = r.getLong(TEMPO) + 1L;
        r.setLong(TEMPO, t);
        return t;
    }

    // ---- salas dos fundos ----
    public static List<Sala> salas(EntityPlayer p) {
        List<Sala> saida = new ArrayList<Sala>();
        NBTTagList lista = raiz(p).getTagList(SALAS, 10);
        for (int i = 0; i < lista.tagCount(); i++) {
            saida.add(Sala.deNBT(lista.getCompoundTagAt(i)));
        }
        return saida;
    }

    public static void adicionarSala(EntityPlayer p, Sala s) {
        NBTTagCompound r = raiz(p);
        NBTTagList lista = r.getTagList(SALAS, 10);
        lista.appendTag(s.paraNBT());
        r.setTag(SALAS, lista);
    }
}
