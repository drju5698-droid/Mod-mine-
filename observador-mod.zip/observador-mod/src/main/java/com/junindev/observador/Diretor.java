package com.junindev.observador;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.SoundEvents;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;

/**
 * O "diretor de terror": decide quando cada coisa acontece pra cada jogador.
 * TODO: novos eventos entram em dispararEvento() (aleatorios) ou em aoTickJogador() (por condicao).
 */
@Mod.EventBusSubscriber(modid = ObservadorMod.MODID)
public final class Diretor {
    private Diretor() {}

    private static final Map<UUID, Long> PROXIMO = new HashMap<UUID, Long>();
    private static final Map<UUID, Integer> FASE_ANTERIOR = new HashMap<UUID, Integer>();
    private static final Map<UUID, Long> PROXIMA_MORTE = new HashMap<UUID, Long>();
    private static final Map<UUID, Long> CASA_AGENDADA = new HashMap<UUID, Long>();
    private static final Map<UUID, Long> CASA_LIBERA = new HashMap<UUID, Long>();
    private static final Map<UUID, Long> SALA_LIBERA = new HashMap<UUID, Long>();
    private static final List<Tarefa> FILA = new ArrayList<Tarefa>();

    // intervalo entre eventos (em segundos) por fase: {min, max}
    private static final int[][] INTERVALO = { { 90, 180 }, { 40, 90 }, { 25, 60 }, { 15, 40 } };

    private static final class Tarefa {
        int ticks;
        final Runnable acao;

        Tarefa(int ticks, Runnable acao) {
            this.ticks = ticks;
            this.acao = acao;
        }
    }

    /** Executa algo daqui a N ticks (na thread do servidor). */
    public static void agendar(int ticks, Runnable acao) {
        if (ticks <= 0) {
            acao.run();
        } else {
            FILA.add(new Tarefa(ticks, acao));
        }
    }

    public static void limpar() {
        PROXIMO.clear();
        FASE_ANTERIOR.clear();
        PROXIMA_MORTE.clear();
        CASA_AGENDADA.clear();
        CASA_LIBERA.clear();
        SALA_LIBERA.clear();
        FILA.clear();
        Apagao.limpar();
        Ambiente.limpar();
        Sustos.limparFalas();
    }

    // ------------------------------------------------------------------ tick do jogador

    @SubscribeEvent
    public static void aoTickJogador(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != Side.SERVER) return;

        EntityPlayer p = e.player;
        World w = p.world;

        long jogados = Dados.somarTick(p); // conta o tempo de jogatina em qualquer dimensao

        if (w.provider.getDimension() != 0 || p.isSpectator()) {
            Ambiente.definir(p, 0);
            return;
        }

        int fase = Fase.de(w);
        UUID id = p.getUniqueID();
        long agora = w.getTotalWorldTime();

        // aviso sutil quando a fase sobe com o jogador dentro do jogo
        Integer anterior = FASE_ANTERIOR.put(id, fase);
        if (anterior != null && fase > anterior.intValue()) {
            Sustos.tocarEm(p, SoundEvents.ENTITY_WITHER_AMBIENT, p.posX, p.posY + 8.0D, p.posZ, 0.6F, 0.5F);
        }

        if (fase >= 1) {
            if (p.ticksExisted % 4 == 0) Corrupcao.corroer(p, fase);
            if (Config.CLIMA_PESADO && p.ticksExisted % 400 == 0 && w instanceof WorldServer) {
                Corrupcao.climaPesado((WorldServer) w, fase);
            }
        }

        // animais morrem depois de X horas de jogatina
        if (jogados >= Config.JOGATINA_PARA_MATAR && p.ticksExisted % 20 == 3) {
            tickAnimais(p, id, agora);
        }

        // apagao, clima do cliente e Eco (a cada 0,5 s)
        if (p.ticksExisted % 10 == 0) {
            if (Apagao.ativo(p)) Apagao.tick(p, agora);
            atualizarAmbiente(p);
            cuidarDasSalas(p, w);
        }

        // observador na janela de casa (a cada 5 s)
        if (p.ticksExisted % 100 == 7) {
            visitaCasa(p, w, agora);
        }

        // eventos aleatorios
        Long prox = PROXIMO.get(id);
        if (prox == null) {
            PROXIMO.put(id, agora + sortear(p, fase));
            return;
        }
        if (agora < prox.longValue()) return;

        PROXIMO.put(id, agora + sortear(p, fase));
        dispararEvento(p, fase);
    }

    private static void tickAnimais(EntityPlayer p, UUID id, long agora) {
        Long pm = PROXIMA_MORTE.get(id);
        if (pm == null) {
            PROXIMA_MORTE.put(id, agora + segundos(p, 20, 80)); // a primeira vem logo depois de bater a marca
        } else if (agora >= pm.longValue()) {
            boolean matou = Corrupcao.matarAnimal(p);
            PROXIMA_MORTE.put(id, agora + (matou ? segundos(p, Config.ANIMAL_INTERVALO_MIN, Config.ANIMAL_INTERVALO_MAX) : 20L * 30L));
        }
    }

    private static void atualizarAmbiente(EntityPlayer p) {
        int estado = 0;
        if (Apagao.ativo(p)) {
            estado = 1;
        } else {
            for (Sala s : Dados.salas(p)) {
                if (s.dentro(p.posX, p.posY, p.posZ)) {
                    estado = 2;
                    break;
                }
            }
        }
        Ambiente.definir(p, estado);
    }

    private static void cuidarDasSalas(EntityPlayer p, World w) {
        for (Sala s : Dados.salas(p)) {
            if (s.distCentro2(p.posX, p.posZ) < 28.0D * 28.0D) {
                SalaFundos.garantirEco(w, s);
            }
        }
    }

    private static void visitaCasa(EntityPlayer p, World w, long agora) {
        UUID id = p.getUniqueID();
        if (!Fase.ehNoite(w) || Fase.noiteAtual(w) < Config.CASA_NOITE_MIN || Apagao.ativo(p) || !Casa.estaEmCasa(p)) {
            CASA_AGENDADA.remove(id); // saiu de casa (ou nao e noite): cancela a visita
            return;
        }

        Random r = p.getRNG();
        Long ag = CASA_AGENDADA.get(id);
        if (ag == null) {
            Long lib = CASA_LIBERA.get(id);
            if (lib != null && agora < lib.longValue()) return;
            CASA_AGENDADA.put(id, agora + 20L * (10 + r.nextInt(26))); // chega entre 10 e 35 s depois de voce entrar
            return;
        }
        if (agora < ag.longValue()) return;

        CASA_AGENDADA.remove(id);
        boolean ok = Sustos.observadorCasa(p);
        CASA_LIBERA.put(id, agora + (ok ? 20L * (180 + r.nextInt(240)) : 20L * 20));
    }

    // ------------------------------------------------------------------ outros eventos do forge

    @SubscribeEvent
    public static void aoTickServidor(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || FILA.isEmpty()) return;

        List<Runnable> prontos = new ArrayList<Runnable>();
        Iterator<Tarefa> it = FILA.iterator();
        while (it.hasNext()) {
            Tarefa t = it.next();
            t.ticks--;
            if (t.ticks <= 0) {
                prontos.add(t.acao);
                it.remove();
            }
        }
        for (Runnable r : prontos) {
            try {
                r.run();
            } catch (Exception ex) {
                ObservadorMod.LOG.warn("Tarefa agendada falhou", ex);
            }
        }
    }

    @SubscribeEvent
    public static void aoEntrar(PlayerEvent.PlayerLoggedInEvent e) {
        Ambiente.forcar(e.player, 0); // cliente comeca limpo
    }

    @SubscribeEvent
    public static void aoSair(PlayerEvent.PlayerLoggedOutEvent e) {
        EntityPlayer p = e.player;
        UUID id = p.getUniqueID();
        if (Apagao.ativo(p)) Apagao.terminar(p, false);
        PROXIMO.remove(id);
        FASE_ANTERIOR.remove(id);
        PROXIMA_MORTE.remove(id);
        CASA_AGENDADA.remove(id);
        Ambiente.esquecer(id);
    }

    /** Morreu durante o apagao? Acabou. */
    @SubscribeEvent
    public static void aoMorrer(LivingDeathEvent e) {
        if (e.getEntityLiving() instanceof EntityPlayerMP) {
            EntityPlayer p = (EntityPlayer) e.getEntityLiving();
            if (Apagao.ativo(p)) Apagao.terminar(p, false);
        }
    }

    // ------------------------------------------------------------------ sorteio de eventos

    private static long segundos(EntityPlayer p, int min, int max) {
        return 20L * (min + p.getRNG().nextInt(max - min + 1));
    }

    private static int sortear(EntityPlayer p, int fase) {
        int[] f = INTERVALO[fase];
        return 20 * (f[0] + p.getRNG().nextInt(f[1] - f[0] + 1));
    }

    static void dispararEvento(final EntityPlayer p, final int fase) {
        final World w = p.world;
        Random r = p.getRNG();
        UUID id = p.getUniqueID();
        long agora = w.getTotalWorldTime();

        if (Apagao.ativo(p)) return; // durante o apagao o proprio apagao cuida dos sustos

        if (fase == 0) {
            // noites 1 e 2: ele so observa de longe. Nao mexe em nada.
            if (Fase.ehNoite(w) && w.canSeeSky(p.getPosition()) && r.nextInt(100) < 60) {
                Sustos.observador(p);
            }
            return;
        }

        // evento raro: escuridao total (fase 2+)
        if (fase >= 2 && Apagao.podeIniciar(p, agora) && r.nextInt(100) < Config.APAGAO_CHANCE) {
            Apagao.iniciar(p);
            return;
        }

        // caverna profunda: chance de abrir a sala dos fundos
        if (p.posY < Config.SALA_Y_MAX && !w.canSeeSky(p.getPosition())) {
            Long lib = SALA_LIBERA.get(id);
            boolean livre = lib == null || agora >= lib.longValue();
            if (livre && Dados.salas(p).size() < Config.SALA_MAX_POR_JOGADOR && r.nextInt(100) < Config.SALA_CHANCE) {
                if (SalaFundos.tentarCriar(p) != null) {
                    SALA_LIBERA.put(id, agora + Config.SALA_COOLDOWN);
                    return;
                }
            }
        }

        int sorte = r.nextInt(100);
        if (sorte < 25) {
            Sustos.observador(p);
        } else if (sorte < 50) {
            Sustos.vulto(p, fase);
        } else if (sorte < 70 && Config.TOCHAS_APAGAM) {
            Corrupcao.apagarTochas(p, fase);
        } else {
            Sustos.somPerturbador(p, fase);
        }

        // fase 3: as vezes vem outro susto logo em seguida
        if (fase >= 3 && r.nextInt(100) < 35) {
            agendar(40 + r.nextInt(80), new Runnable() {
                @Override
                public void run() {
                    if (!p.isDead && p.world == w) dispararEvento(p, fase);
                }
            });
        }
    }
}
