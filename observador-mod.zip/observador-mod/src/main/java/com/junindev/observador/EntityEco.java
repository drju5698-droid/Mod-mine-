package com.junindev.observador;

import java.util.ArrayDeque;

import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * O Eco: mora na sala dos fundos. Fica olhando pra voce e copia seus movimentos "do outro lado do espelho":
 * onde voce anda pra frente ele anda pra frente tambem, vindo na sua direcao. Copia agachar e bater, com um
 * pequeno atraso. Nao da pra tocar nele.
 */
public class EntityEco extends EntityLiving {

    private Sala sala;
    private final ArrayDeque<double[]> historico = new ArrayDeque<double[]>();
    private int semJogador = 0;
    private boolean carregadoDoDisco = false;

    public EntityEco(World w) {
        super(w);
        setSize(0.4F, 1.2F);
        setEntityInvulnerable(true);
        setSilent(true);
        setNoGravity(true);
        enablePersistence();
        isImmuneToFire = true;
        experienceValue = 0;
    }

    public void definirSala(Sala s) {
        sala = s;
    }

    @Override
    public boolean canBeCollidedWith() {
        return false;
    }

    @Override
    public boolean canBePushed() {
        return false;
    }

    @Override
    public boolean attackEntityFrom(DamageSource fonte, float quanto) {
        if (fonte == DamageSource.OUT_OF_WORLD) setDead();
        return false;
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound c) {
        super.readEntityFromNBT(c);
        carregadoDoDisco = true;
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (world.isRemote) return;

        if (carregadoDoDisco || sala == null) {
            setDead();
            return;
        }

        EntityPlayer p = Util.jogadorMaisProximo(world, this, 40.0D);
        if (p == null) {
            if (++semJogador > 100) setDead(); // sem ninguem por perto: some (volta quando o jogador voltar)
            return;
        }
        semJogador = 0;

        // posicao do jogador ha ECO_ATRASO ticks
        historico.addLast(new double[] { p.posX, p.posY, p.posZ, p.isSneaking() ? 1.0D : 0.0D });
        while (historico.size() > Config.ECO_ATRASO + 1) historico.pollFirst();
        double[] a = historico.peekFirst();

        if (sala.interior(a[0], a[1], a[2])) {
            double[] m = sala.espelhar(a[0], a[2]);
            double y = sala.piso + 1.0D + Math.max(0.0D, Math.min(2.5D, a[1] - (sala.piso + 1.0D)));
            if (livre(m[0], y, m[1])) {
                setPosition(m[0], y, m[1]); // setPosition (e nao setLocation) pra manter a animacao das pernas
            }
            setSneaking(a[3] > 0.5D);
        }

        motionX = 0.0D;
        motionY = 0.0D;
        motionZ = 0.0D;
        if (p.isSwingInProgress && !isSwingInProgress) swingArm(EnumHand.MAIN_HAND);
        Util.virarPara(this, p);
    }

    private boolean livre(double x, double y, double z) {
        BlockPos pe = new BlockPos(x, y, z);
        return !world.getBlockState(pe).getMaterial().blocksMovement()
                && !world.getBlockState(pe.up()).getMaterial().blocksMovement();
    }
}
