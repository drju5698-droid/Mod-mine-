package com.junindev.observador;

import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/**
 * Uma entidade, tres comportamentos:
 *  - OBSERVADOR: aparece longe, fica parado te encarando. Se voce chegar perto ou encarar demais, some.
 *  - VULTO: aparece perto (de preferencia nas suas costas) e some assim que voce olha.
 *  - CASA: aparece 10-15 blocos da sua casa, a noite, e fica 5 segundos te olhando (nao some se voce olhar de volta).
 * Nao da pra bater, nao empurra, nao dropa nada e nao e salva no mundo.
 */
public class EntityObservador extends EntityLiving {

    public static final int TIPO_OBSERVADOR = 0;
    public static final int TIPO_VULTO = 1;
    public static final int TIPO_CASA = 2;

    private static final DataParameter<Integer> TIPO =
            EntityDataManager.<Integer>createKey(EntityObservador.class, DataSerializers.VARINT);

    private int vida = 0;
    private int vidaMax = 20 * 60;
    private int tempoVisto = 0;
    private boolean viuPrimeiraVez = false;
    private boolean carregadoDoDisco = false;

    public EntityObservador(World w) {
        super(w);
        setSize(0.6F, 2.2F);
        setEntityInvulnerable(true);
        setSilent(true);
        enablePersistence();
        isImmuneToFire = true;
        experienceValue = 0;
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        dataManager.register(TIPO, TIPO_OBSERVADOR);
    }

    public int getTipo() {
        return dataManager.get(TIPO);
    }

    public void setTipo(int t) {
        dataManager.set(TIPO, t);
    }

    public boolean ehVulto() {
        return getTipo() == TIPO_VULTO;
    }

    public void setVidaMax(int ticks) {
        vidaMax = ticks;
    }

    // ---- ele e um fantasma: ninguem encosta ----
    @Override
    public boolean canBeCollidedWith() {
        return false;
    }

    @Override
    public boolean canBePushed() {
        return false;
    }

    @Override
    public boolean attackEntityFrom(DamageSource fonte, float quanto) {
        if (fonte == DamageSource.OUT_OF_WORLD) {
            setDead(); // /kill funciona
        }
        return false;
    }

    // ---- nao persiste no save: se recarregar o mundo, ele some ----
    @Override
    public void readEntityFromNBT(NBTTagCompound c) {
        super.readEntityFromNBT(c);
        carregadoDoDisco = true;
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();

        if (world.isRemote) {
            // fumaca escura saindo dele (so visual)
            if (rand.nextInt(5) == 0) {
                world.spawnParticle(EnumParticleTypes.SMOKE_NORMAL,
                        posX + (rand.nextDouble() - 0.5D) * 0.7D,
                        posY + rand.nextDouble() * 2.0D,
                        posZ + (rand.nextDouble() - 0.5D) * 0.7D,
                        0.0D, 0.01D, 0.0D);
            }
            return;
        }

        if (carregadoDoDisco) {
            setDead();
            return;
        }

        vida++;
        if (vida > vidaMax) {
            boolean casa = getTipo() == TIPO_CASA;
            if (casa) {
                EntityPlayer a = Util.jogadorMaisProximo(world, this, 64.0D);
                if (a != null) Sustos.chamarNome(a, 30);
            }
            sumir(casa);
            return;
        }

        EntityPlayer alvo = Util.jogadorMaisProximo(world, this, 160.0D);
        if (alvo == null) {
            if (vida > 200) sumir(false);
            return;
        }

        Util.virarPara(this, alvo);
        double dist = getDistance(alvo);

        switch (getTipo()) {
            case TIPO_VULTO: logicaVulto(alvo); break;
            case TIPO_CASA: logicaCasa(alvo, dist); break;
            default: logicaObservador(alvo, dist); break;
        }
    }

    private void logicaObservador(EntityPlayer alvo, double dist) {
        if (dist < Config.OBS_SUMIR_PERTO) {
            sumir(true);
            return;
        }
        if (Util.estaOlhando(alvo, this, 0.97D)) {
            tempoVisto++;
            if (!viuPrimeiraVez) {
                viuPrimeiraVez = true;
                Sustos.somVisto(alvo);
            }
            if (tempoVisto > Config.OBS_OLHAR_MAX) {
                sumir(false); // encarou demais: ele some sem fazer barulho
            }
        } else if (tempoVisto > 0 && ticksExisted % 2 == 0) {
            tempoVisto--;
        }
    }

    private void logicaVulto(EntityPlayer alvo) {
        if (Util.estaOlhando(alvo, this, 0.80D)) {
            tempoVisto++;
            if (tempoVisto >= 7) {
                sumir(true); // viu? entao ja era
                Sustos.chamarNome(alvo, 45);
            }
        }
    }

    /** Ele fica parado ate acabar o tempo. Olhar de volta nao adianta. So some se voce correr pra cima dele. */
    private void logicaCasa(EntityPlayer alvo, double dist) {
        if (!viuPrimeiraVez && Util.estaOlhando(alvo, this, 0.97D)) {
            viuPrimeiraVez = true;
            Sustos.somVisto(alvo);
        }
        if (dist < 5.0D) {
            sumir(true);
        }
    }

    private void sumir(boolean assustar) {
        if (assustar && world instanceof WorldServer) {
            ((WorldServer) world).spawnParticle(EnumParticleTypes.SMOKE_LARGE,
                    posX, posY + 1.0D, posZ, 25, 0.3D, 0.9D, 0.3D, 0.01D);
            if (ehVulto() && Fase.de(world) >= 2 && rand.nextInt(3) == 0) {
                world.playSound(null, posX, posY, posZ, SoundEvents.ENTITY_ENDERMEN_SCREAM,
                        SoundCategory.AMBIENT, 0.7F, 0.6F);
            }
        }
        setDead();
    }
}
