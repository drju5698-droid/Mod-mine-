package com.junindev.observador;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackMelee;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/**
 * Sombrinha: bichinho preto de olhos vermelhos do APAGAO. Anda devagar atras do jogador e,
 * as vezes, bate (nem toda pancada acerta). Se voce bater nela, ela vira fumaca.
 */
public class EntitySombra extends EntityCreature {

    private int vida = 0;
    private boolean carregadoDoDisco = false;

    public EntitySombra(World w) {
        super(w);
        setSize(0.4F, 1.1F);
        enablePersistence();
        isImmuneToFire = true;
        experienceValue = 0;
    }

    @Override
    protected void initEntityAI() {
        tasks.addTask(1, new EntityAISwimming(this));
        tasks.addTask(2, new EntityAIAttackMelee(this, 1.0D, false));
        tasks.addTask(5, new EntityAIWander(this, 0.8D));
        tasks.addTask(6, new EntityAIWatchClosest(this, EntityPlayer.class, 12.0F));
        targetTasks.addTask(1, new EntityAINearestAttackableTarget<EntityPlayer>(this, EntityPlayer.class, false));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(6.0D);
        getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.23D);
        getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(32.0D);
    }

    /** "As vezes bate": a animacao acontece sempre, mas so uma parte das pancadas acerta. */
    @Override
    public boolean attackEntityAsMob(Entity alvo) {
        swingArm(EnumHand.MAIN_HAND);
        if (rand.nextInt(100) >= Config.SOMBRA_CHANCE_BATER) return false;
        return alvo.attackEntityFrom(DamageSource.causeMobDamage(this), Config.SOMBRA_DANO);
    }

    @Override
    public boolean attackEntityFrom(DamageSource fonte, float quanto) {
        if (fonte == DamageSource.OUT_OF_WORLD) {
            setDead();
            return false;
        }
        if (!world.isRemote && fonte.getTrueSource() instanceof EntityPlayer) {
            dissipar(); // apanhou? vira fumaca (e o apagao manda outra depois)
        }
        return false;
    }

    public void dissipar() {
        if (world instanceof WorldServer) {
            ((WorldServer) world).spawnParticle(EnumParticleTypes.SMOKE_LARGE,
                    posX, posY + 0.6D, posZ, 12, 0.2D, 0.4D, 0.2D, 0.01D);
        }
        setDead();
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound c) {
        super.readEntityFromNBT(c);
        carregadoDoDisco = true;
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (world.isRemote) return;
        if (carregadoDoDisco) {
            setDead();
            return;
        }
        vida++;
        if (vida > 20 * 60 * 4) dissipar(); // nunca fica pra sempre
    }
}
