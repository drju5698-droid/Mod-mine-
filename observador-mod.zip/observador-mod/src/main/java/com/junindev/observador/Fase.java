package com.junindev.observador;

import net.minecraft.world.World;

/** Calcula em qual "fase" o mundo esta, so olhando a hora do mundo (funciona igual no cliente e no servidor). */
public final class Fase {
    private Fase() {}

    public static final long DIA = 24000L;
    private static final long INICIO_NOITE = 13000L;
    private static final long FIM_NOITE = 23000L;

    public static boolean ehNoite(World w) {
        long t = Math.max(0L, w.getWorldTime()) % DIA;
        return t >= INICIO_NOITE && t < FIM_NOITE;
    }

    /** 0 = ainda nao anoiteceu nenhuma vez. A noite N comeca no fim da tarde do dia N-1. */
    public static int noiteAtual(World w) {
        long t = Math.max(0L, w.getWorldTime());
        long dia = t / DIA;
        long hora = t % DIA;
        return (int) (dia + (hora >= INICIO_NOITE ? 1 : 0));
    }

    /** 0 = so observa | 1 = despertou (noite 3) | 2 = piora (noite 5) | 3 = pesadelo (noite 7) */
    public static int de(World w) {
        int n = noiteAtual(w);
        if (n >= Config.NOITE_FASE_3) return 3;
        if (n >= Config.NOITE_FASE_2) return 2;
        if (n >= Config.NOITE_DESPERTAR) return 1;
        return 0;
    }
}
