package com.junindev.observador;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** Olhos que brilham no escuro (mesma tecnica dos olhos da aranha/enderman). Serve pra qualquer um dos nossos bichos. */
@SideOnly(Side.CLIENT)
public class LayerOlhos<T extends EntityLiving> implements LayerRenderer<T> {

    private final RenderLiving<T> render;
    private final ResourceLocation textura;

    public LayerOlhos(RenderLiving<T> render, ResourceLocation textura) {
        this.render = render;
        this.textura = textura;
    }

    @Override
    public void doRenderLayer(T e, float limbSwing, float limbSwingAmount, float partialTicks,
                              float ageInTicks, float netHeadYaw, float headPitch, float scale) {
        render.bindTexture(textura);
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.blendFunc(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ONE);
        GlStateManager.depthMask(true);

        int luz = 61680; // brilho maximo, ignora a escuridao
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float) (luz % 65536), (float) (luz / 65536));
        GlStateManager.enableLighting();
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);

        render.getMainModel().render(e, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);

        int normal = e.getBrightnessForRender();
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float) (normal % 65536), (float) (normal / 65536));
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
    }

    @Override
    public boolean shouldCombineTextures() {
        return false;
    }
}
