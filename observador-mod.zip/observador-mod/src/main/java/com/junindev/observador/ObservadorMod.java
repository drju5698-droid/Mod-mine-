package com.junindev.observador;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.event.FMLServerStoppingEvent;

@Mod(modid = ObservadorMod.MODID, name = ObservadorMod.NOME, version = ObservadorMod.VERSAO, acceptedMinecraftVersions = "[1.12.2]")
public class ObservadorMod {

    public static final String MODID = "observador";
    public static final String NOME = "O Observador";
    public static final String VERSAO = "1.1.0";
    public static final Logger LOG = LogManager.getLogger(MODID);

    @Mod.EventHandler
    public void aoPreIniciar(FMLPreInitializationEvent e) {
        Rede.iniciar();
    }

    @Mod.EventHandler
    public void aoIniciarServidor(FMLServerStartingEvent e) {
        e.registerServerCommand(new ComandoObservador());
    }

    @Mod.EventHandler
    public void aoPararServidor(FMLServerStoppingEvent e) {
        Diretor.limpar();
    }
}
