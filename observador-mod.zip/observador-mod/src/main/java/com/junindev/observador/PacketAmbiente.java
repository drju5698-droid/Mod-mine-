package com.junindev.observador;

import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** Estado do ambiente no cliente: 0 = normal, 1 = apagao (escuridao total), 2 = dentro da sala dos fundos. */
public class PacketAmbiente implements IMessage {

    public int estado;

    public PacketAmbiente() {}

    public PacketAmbiente(int estado) {
        this.estado = estado;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        estado = buf.readInt();
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeInt(estado);
    }

    public static class Handler implements IMessageHandler<PacketAmbiente, IMessage> {
        @Override
        public IMessage onMessage(PacketAmbiente msg, MessageContext ctx) {
            ClienteEstado.estado = msg.estado;
            return null;
        }
    }
}
