package com.junindev.observador;

import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

/** Canal de rede servidor -> cliente (so manda o "estado do ambiente"). */
public final class Rede {
    private Rede() {}

    public static final SimpleNetworkWrapper CANAL = NetworkRegistry.INSTANCE.newSimpleChannel(ObservadorMod.MODID);

    public static void iniciar() {
        CANAL.registerMessage(PacketAmbiente.Handler.class, PacketAmbiente.class, 0, Side.CLIENT);
    }
}
