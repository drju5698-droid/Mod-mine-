package com.junindev.observador;

import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.EntityEntry;
import net.minecraftforge.fml.common.registry.EntityEntryBuilder;

@Mod.EventBusSubscriber(modid = ObservadorMod.MODID)
public final class Registro {
    private Registro() {}

    @SubscribeEvent
    public static void aoRegistrarEntidades(RegistryEvent.Register<EntityEntry> e) {
        e.getRegistry().register(EntityEntryBuilder.create()
                .entity(EntityObservador.class)
                .id(new ResourceLocation(ObservadorMod.MODID, "observador"), 0)
                .name("observador")
                .tracker(128, 3, true)
                .build());

        e.getRegistry().register(EntityEntryBuilder.create()
                .entity(EntitySombra.class)
                .id(new ResourceLocation(ObservadorMod.MODID, "sombra"), 1)
                .name("sombra")
                .tracker(80, 2, true)
                .build());

        e.getRegistry().register(EntityEntryBuilder.create()
                .entity(EntityEco.class)
                .id(new ResourceLocation(ObservadorMod.MODID, "eco"), 2)
                .name("eco")
                .tracker(80, 1, false)
                .build());
    }
}
