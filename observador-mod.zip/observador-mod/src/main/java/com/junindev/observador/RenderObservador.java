package com.junindev.observador;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderBiped;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** Silhueta preta, alta e magra, com olhos brancos brilhando. */
@SideOnly(Side.CLIENT)
public class RenderObservador extends RenderBiped<EntityObservador> {

    private static final ResourceLocation TEXTURA =
            new ResourceLocation(ObservadorMod.MODID, "textures/entity/observador.png");
    private static final ResourceLocation OLHOS =
            new ResourceLocation(ObservadorMod.MODID, "textures/entity/observador_olhos.png");

    public RenderObservador(RenderManager manager) {
        super(manager, new ModelBiped(), 0.0F);
        addLayer(new LayerOlhos<EntityObservador>(this, OLHOS));
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityObservador e) {
        return TEXTURA;
    }

    @Override
    protected void preRenderCallback(EntityObservador e, float partialTicks) {
        GlStateManager.scale(0.9F, 1.2F, 0.9F); // mais alto e mais magro que o Steve
    }
}
