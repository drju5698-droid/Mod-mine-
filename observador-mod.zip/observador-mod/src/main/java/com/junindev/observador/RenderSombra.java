package com.junindev.observador;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderBiped;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * Versao "menor" da silhueta. Serve pra Sombrinha (olhos vermelhos) e pro Eco (olhos brancos).
 */
@SideOnly(Side.CLIENT)
public class RenderSombra<T extends EntityLiving> extends RenderBiped<T> {

    private static final ResourceLocation CORPO_SOMBRA = new ResourceLocation(ObservadorMod.MODID, "textures/entity/sombra.png");
    private static final ResourceLocation OLHOS_SOMBRA = new ResourceLocation(ObservadorMod.MODID, "textures/entity/sombra_olhos.png");
    private static final ResourceLocation CORPO_ECO = new ResourceLocation(ObservadorMod.MODID, "textures/entity/observador.png");
    private static final ResourceLocation OLHOS_ECO = new ResourceLocation(ObservadorMod.MODID, "textures/entity/observador_olhos.png");

    private final ResourceLocation corpo;
    private final float escala;

    public RenderSombra(RenderManager manager, boolean eco, float escala) {
        super(manager, new ModelBiped(), 0.0F);
        this.corpo = eco ? CORPO_ECO : CORPO_SOMBRA;
        this.escala = escala;
        addLayer(new LayerOlhos<T>(this, eco ? OLHOS_ECO : OLHOS_SOMBRA));
    }

    @Override
    public void doRender(T entity, double x, double y, double z, float entityYaw, float partialTicks) {
        ((ModelBiped) getMainModel()).isSneak = entity.isSneaking(); // o Eco copia o agachar
        super.doRender(entity, x, y, z, entityYaw, partialTicks);
    }

    @Override
    protected ResourceLocation getEntityTexture(T e) {
        return corpo;
    }

    @Override
    protected void preRenderCallback(T e, float partialTicks) {
        GlStateManager.scale(escala, escala, escala);
    }
}
