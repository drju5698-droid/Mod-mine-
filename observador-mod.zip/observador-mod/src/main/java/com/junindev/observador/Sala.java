package com.junindev.observador;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

/**
 * Geometria da "sala dos fundos": 17x17 blocos, piso em y=piso, teto em piso+4.
 * Coordenadas locais: a = profundidade (0 = parede da entrada), b = lateral (0..16), h = altura.
 * A porta de entrada fica em a=0, b=10. 'dir' diz pra que lado a sala cresce a partir da porta:
 * 0 = leste (+x), 1 = oeste (-x), 2 = sul (+z), 3 = norte (-z).
 */
public final class Sala {
    public static final int N = 17;
    public static final int ENTRADA_B = 10;

    public final int ex;    // x do bloco da porta de entrada
    public final int ez;    // z do bloco da porta de entrada
    public final int piso;  // y do piso
    public final int dir;

    public Sala(int ex, int ez, int piso, int dir) {
        this.ex = ex;
        this.ez = ez;
        this.piso = piso;
        this.dir = dir;
    }

    // ---- local (blocos) -> mundo ----
    public int mx(int a, int b) {
        switch (dir) {
            case 0: return ex + a;
            case 1: return ex - a;
            default: return ex + (b - ENTRADA_B);
        }
    }

    public int mz(int a, int b) {
        switch (dir) {
            case 2: return ez + a;
            case 3: return ez - a;
            default: return ez + (b - ENTRADA_B);
        }
    }

    public BlockPos pos(int a, int b, int h) {
        return new BlockPos(mx(a, b), piso + h, mz(a, b));
    }

    // ---- mundo (continuo) <-> local (continuo) ----
    public double u(double x, double z) {
        switch (dir) {
            case 0: return x - ex;
            case 1: return ex + 1.0D - x;
            case 2: return z - ez;
            default: return ez + 1.0D - z;
        }
    }

    public double v(double x, double z) {
        return dir < 2 ? (z - ez + ENTRADA_B) : (x - ex + ENTRADA_B);
    }

    public double wx(double u, double v) {
        switch (dir) {
            case 0: return ex + u;
            case 1: return ex + 1.0D - u;
            default: return ex + v - ENTRADA_B;
        }
    }

    public double wz(double u, double v) {
        switch (dir) {
            case 2: return ez + u;
            case 3: return ez + 1.0D - u;
            default: return ez + v - ENTRADA_B;
        }
    }

    /** Dentro do salao (inclui a porta). Usado pro clima do cliente. */
    public boolean dentro(double x, double y, double z) {
        double u = u(x, z), v = v(x, z);
        return u >= 0.0D && u < N && v >= 0.0D && v < N && y >= piso + 0.5D && y < piso + 5.0D;
    }

    /** Dentro da area util (sem as paredes externas). Usado pelo Eco. */
    public boolean interior(double x, double y, double z) {
        double u = u(x, z), v = v(x, z);
        return u >= 1.0D && u < N - 1 && v >= 1.0D && v < N - 1 && y >= piso + 0.5D && y < piso + 4.5D;
    }

    public double centroX() {
        return wx(N / 2.0D, N / 2.0D);
    }

    public double centroZ() {
        return wz(N / 2.0D, N / 2.0D);
    }

    public double distCentro2(double x, double z) {
        double dx = x - centroX(), dz = z - centroZ();
        return dx * dx + dz * dz;
    }

    public AxisAlignedBB caixa() {
        double x1 = wx(0, 0), x2 = wx(N, N), z1 = wz(0, 0), z2 = wz(N, N);
        return new AxisAlignedBB(Math.min(x1, x2), piso, Math.min(z1, z2), Math.max(x1, x2), piso + 6, Math.max(z1, z2));
    }

    /** Reflexo do ponto atraves do centro da sala: o Eco anda "espelhado" em relacao a voce. */
    public double[] espelhar(double x, double z) {
        double uu = N - u(x, z), vv = N - v(x, z);
        return new double[] { wx(uu, vv), wz(uu, vv) };
    }

    /** Onde o Eco fica parado esperando (canto oposto a entrada). */
    public double[] descanso() {
        return new double[] { wx(14.5D, 6.5D), wz(14.5D, 6.5D) };
    }

    // ---- NBT ----
    public NBTTagCompound paraNBT() {
        NBTTagCompound c = new NBTTagCompound();
        c.setInteger("ex", ex);
        c.setInteger("ez", ez);
        c.setInteger("piso", piso);
        c.setInteger("dir", dir);
        return c;
    }

    public static Sala deNBT(NBTTagCompound c) {
        return new Sala(c.getInteger("ex"), c.getInteger("ez"), c.getInteger("piso"), c.getInteger("dir"));
    }
}
