package com.junindev.observador;

import java.util.Arrays;
import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.BlockColored;
import net.minecraft.block.BlockOre;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

/**
 * Gera a "sala dos fundos": um salao amarelado de corredores e portas, piso de carpete escuro,
 * quase sem luz, escondido na rocha e ligado ao jogador por um tunel novo. Dentro mora o Eco.
 * TODO: variar o layout (mais de um tipo de sala) e dar um tema novo por fase.
 */
public final class SalaFundos {
    private SalaFundos() {}

    // ------------------------------------------------------------------ layout

    private static boolean ehPorta(int a, int b) {
        if (a == 0 && b == Sala.ENTRADA_B) return true; // entrada
        if (a > 0 && a < 16 && b > 0 && b < 16) {
            if (a % 4 == 0 && b % 4 == 2) return true;
            if (b % 4 == 0 && a % 4 == 2) return true;
        }
        return false;
    }

    private static boolean ehParede(int a, int b) {
        if (a == 0 || b == 0 || a == 16 || b == 16) return true;
        boolean linhaA = a % 4 == 0;
        boolean linhaB = b % 4 == 0;
        if (linhaA && linhaB) return true;   // pilar
        if (linhaA) return b % 4 != 2;       // parede (porta quando b%4==2)
        if (linhaB) return a % 4 != 2;
        return false;
    }

    private static boolean temSangue(int a, int b) {
        if (a <= 0 || b <= 0 || a >= 16 || b >= 16) return false;
        if (Math.abs(a - 14) + Math.abs(b - 6) <= 1) return true;  // poca onde o Eco fica
        return (a * 13 + b * 7) % 9 == 0;                            // manchas espalhadas
    }

    private static boolean temLuz(int a, int b) {
        if (a % 4 != 2 || b % 4 != 2) return false;                  // so no centro das celulas
        return ((a / 4) * 7 + (b / 4) * 3) % 5 == 0;                 // so 4 das 16 celulas tem luz
    }

    // ------------------------------------------------------------------ criar

    /** Tenta criar uma sala perto do jogador. Retorna a sala ou null se nao achou lugar seguro. */
    public static Sala tentarCriar(EntityPlayer p) {
        final World w = p.world;
        if (w.provider.getDimension() != 0) return null;
        Random r = p.getRNG();

        int px = MathHelper.floor(p.posX);
        int py = MathHelper.floor(p.posY);
        int pz = MathHelper.floor(p.posZ);
        int piso = py - 1;
        if (piso < 8 || piso > Config.SALA_Y_MAX) return null;

        for (Sala outra : Dados.salas(p)) {
            if (outra.distCentro2(p.posX, p.posZ) < 40.0D * 40.0D) return null; // nada de sala colada em sala
        }

        // direcoes: 0 = +x, 1 = -x, 2 = +z, 3 = -z. Prefere as que ficam "atras" de onde o jogador olha.
        final int[][] dirs = { { 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 } };
        double olharX = -Math.sin(Math.toRadians(p.rotationYaw));
        double olharZ = Math.cos(Math.toRadians(p.rotationYaw));
        final double[] dots = new double[4];
        for (int i = 0; i < 4; i++) dots[i] = dirs[i][0] * olharX + dirs[i][1] * olharZ;
        Integer[] ordem = { 0, 1, 2, 3 };
        Arrays.sort(ordem, (i, j) -> Double.compare(dots[i], dots[j]));

        for (int tentativa = 0; tentativa < 8; tentativa++) {
            int dir = ordem[tentativa % 4];
            if (dots[dir] > 0.5D) continue; // nao abre buraco bem na frente do nariz dele
            int dist = 10 + r.nextInt(5);
            int dx = dirs[dir][0];
            int dz = dirs[dir][1];
            Sala s = new Sala(px + dx * dist, pz + dz * dist, piso, dir);
            if (!valida(w, s, px, py, pz, dx, dz, dist)) continue;
            gerar(w, s, px, py, pz, dx, dz, dist);
            Dados.adicionarSala(p, s);
            return s;
        }
        return null;
    }

    private static boolean natural(IBlockState s) {
        Block b = s.getBlock();
        if (b == Blocks.AIR || b == Blocks.STONE || b == Blocks.DIRT || b == Blocks.GRAVEL || b == Blocks.SAND) return true;
        return b instanceof BlockOre || b == Blocks.REDSTONE_ORE || b == Blocks.LIT_REDSTONE_ORE;
    }

    /** So constroi em rocha natural/ar. Nunca em cima de base, mina, agua ou lava. */
    private static boolean valida(World w, Sala s, int px, int py, int pz, int dx, int dz, int dist) {
        AxisAlignedBB c = s.caixa();
        BlockPos min = new BlockPos(c.minX, c.minY, c.minZ);
        BlockPos max = new BlockPos(c.maxX, c.maxY, c.maxZ);
        if (!w.isAreaLoaded(min, max)) return false;

        for (int a = 0; a < Sala.N; a++) {
            for (int b = 0; b < Sala.N; b++) {
                for (int h = 0; h <= 4; h++) {
                    if (!natural(w.getBlockState(s.pos(a, b, h)))) return false;
                }
            }
        }
        for (int t = 2; t < dist; t++) {
            BlockPos pe = new BlockPos(px + dx * t, py, pz + dz * t);
            if (!corredorOk(w.getBlockState(pe)) || !corredorOk(w.getBlockState(pe.up()))) return false;
        }
        return true;
    }

    private static boolean corredorOk(IBlockState s) {
        return natural(s) || s.getMaterial() == Material.CIRCUITS; // tocha/trilho de mina nao impedem
    }

    private static void gerar(World w, Sala s, int px, int py, int pz, int dx, int dz, int dist) {
        IBlockState ar = Blocks.AIR.getDefaultState();
        IBlockState parede = Blocks.STAINED_HARDENED_CLAY.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.YELLOW);
        IBlockState teto = Blocks.STAINED_HARDENED_CLAY.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.SILVER);
        IBlockState carpete = Blocks.WOOL.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.BROWN);
        IBlockState sangue = Blocks.WOOL.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.RED);
        IBlockState luz = Blocks.GLOWSTONE.getDefaultState();

        for (int a = 0; a < Sala.N; a++) {
            for (int b = 0; b < Sala.N; b++) {
                boolean porta = ehPorta(a, b);
                boolean solido = ehParede(a, b) || porta;

                w.setBlockState(s.pos(a, b, 0), temSangue(a, b) ? sangue : carpete, 2);
                w.setBlockState(s.pos(a, b, 4), temLuz(a, b) ? luz : teto, 2);
                for (int h = 1; h <= 3; h++) {
                    boolean bloco = solido && !(porta && h <= 2); // porta: 2 blocos de vao, 1 de verga
                    w.setBlockState(s.pos(a, b, h), bloco ? parede : ar, 2);
                }
            }
        }

        // tunel ate o jogador
        for (int t = 2; t < dist; t++) {
            BlockPos pe = new BlockPos(px + dx * t, py, pz + dz * t);
            w.setBlockState(pe, ar, 2);
            w.setBlockState(pe.up(), ar, 2);
            if (!w.getBlockState(pe.down()).isTopSolid()) {
                w.setBlockState(pe.down(), Blocks.STONE.getDefaultState(), 2);
            }
        }
    }

    // ------------------------------------------------------------------ eco

    /** Garante que existe um Eco na sala (chamado quando o jogador chega perto). */
    public static void garantirEco(World w, Sala s) {
        if (!w.getEntitiesWithinAABB(EntityEco.class, s.caixa().grow(4.0D)).isEmpty()) return;
        double[] d = s.descanso();
        BlockPos pos = new BlockPos(d[0], s.piso + 1, d[1]);
        if (!w.isBlockLoaded(pos) || !w.isAirBlock(pos)) return;

        EntityEco e = new EntityEco(w);
        e.definirSala(s);
        e.setLocationAndAngles(d[0], s.piso + 1, d[1], 0.0F, 0.0F);
        w.spawnEntity(e);
    }
}
