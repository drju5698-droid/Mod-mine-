package com.junindev.observador;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import net.minecraft.block.SoundType;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

/** Tudo que serve pra dar susto: aparicoes, sons e as falas no chat. */
public final class Sustos {
    private Sustos() {}

    private static final Map<UUID, Long> ULTIMA_FALA = new HashMap<UUID, Long>();

    // %s vira o nome do jogador. TODO: mais falas, e falas que dependem do que o jogador esta fazendo.
    private static final String[] FALAS = {
        "%s.",
        "%s... atras de voce.",
        "Eu estou te vendo, %s.",
        "Nao olha, %s.",
        "%s, voce demorou.",
        "Por que voce ainda esta aqui, %s?",
        "Eu conheco voce, %s.",
        "%s. %s. %s.",
        "Ja da pra ouvir seu coracao, %s."
    };

    // ------------------------------------------------------------------ aparicoes

    /** Faz o Observador aparecer longe, meio de canto de olho. Retorna false se nao achou lugar. */
    public static boolean observador(EntityPlayer p) {
        World w = p.world;
        Random r = p.getRNG();
        if (contar(w, p.getEntityBoundingBox().grow(96.0D), EntityObservador.TIPO_OBSERVADOR) > 0) return false;

        for (int tentativa = 0; tentativa < 14; tentativa++) {
            // 50 a 95 graus pro lado: ele fica na visao periferica, voce descobre quando virar
            double lado = r.nextBoolean() ? 1.0D : -1.0D;
            double ang = Math.toRadians(p.rotationYaw + lado * (50 + r.nextInt(45)));
            double d = Config.OBS_DIST_MIN + r.nextInt(Config.OBS_DIST_MAX - Config.OBS_DIST_MIN + 1);
            int x = MathHelper.floor(p.posX - Math.sin(ang) * d);
            int z = MathHelper.floor(p.posZ + Math.cos(ang) * d);

            if (!w.isBlockLoaded(new BlockPos(x, 64, z))) continue;
            BlockPos topo = w.getTopSolidOrLiquidBlock(new BlockPos(x, 64, z));
            BlockPos chao = Util.acharChao(w, x, z, topo.getY(), 2);
            if (chao == null || !w.canSeeSky(chao)) continue;

            EntityObservador e = new EntityObservador(w);
            e.setTipo(EntityObservador.TIPO_OBSERVADOR);
            e.setVidaMax(20 * (45 + r.nextInt(75)));
            e.setLocationAndAngles(x + 0.5D, chao.getY(), z + 0.5D, r.nextFloat() * 360.0F, 0.0F);
            w.spawnEntity(e);
            return true;
        }
        return false;
    }

    /** Faz um vulto aparecer perto, de preferencia nas suas costas. Some quando voce olha. */
    public static boolean vulto(EntityPlayer p, int fase) {
        World w = p.world;
        Random r = p.getRNG();
        if (contar(w, p.getEntityBoundingBox().grow(48.0D), EntityObservador.TIPO_VULTO) > 0) return false;

        for (int tentativa = 0; tentativa < 16; tentativa++) {
            double ang = Math.toRadians(p.rotationYaw + 180.0D + (r.nextInt(121) - 60));
            double d = fase >= 3 ? 4 + r.nextInt(5) : 7 + r.nextInt(8);
            int x = MathHelper.floor(p.posX - Math.sin(ang) * d);
            int z = MathHelper.floor(p.posZ + Math.cos(ang) * d);
            BlockPos chao = Util.acharChao(w, x, z, MathHelper.floor(p.posY), 4);
            if (chao == null) continue;

            EntityObservador e = new EntityObservador(w);
            e.setTipo(EntityObservador.TIPO_VULTO);
            e.setVidaMax(20 * 8);
            e.setLocationAndAngles(x + 0.5D, chao.getY(), z + 0.5D, 0.0F, 0.0F);
            w.spawnEntity(e);
            return true;
        }
        return false;
    }

    /**
     * O Observador na janela: 10 a 15 blocos de casa, FORA, com linha de visao ate o jogador.
     * Fica CASA_DURACAO ticks (5 s) e some. Retorna false se nao achou ponto com visao.
     */
    public static boolean observadorCasa(EntityPlayer p) {
        World w = p.world;
        Random r = p.getRNG();
        if (contar(w, p.getEntityBoundingBox().grow(64.0D), EntityObservador.TIPO_CASA) > 0) return false;

        Vec3d olhoJogador = new Vec3d(p.posX, p.posY + p.getEyeHeight(), p.posZ);
        for (int tentativa = 0; tentativa < 50; tentativa++) {
            double ang = r.nextDouble() * Math.PI * 2.0D;
            double d = Config.CASA_DIST_MIN + r.nextInt(Config.CASA_DIST_MAX - Config.CASA_DIST_MIN + 1);
            int x = MathHelper.floor(p.posX + Math.cos(ang) * d);
            int z = MathHelper.floor(p.posZ + Math.sin(ang) * d);
            BlockPos chao = Util.acharChao(w, x, z, MathHelper.floor(p.posY), 6);
            if (chao == null || !w.canSeeSky(chao)) continue; // tem que estar la fora

            Vec3d olhoEntidade = new Vec3d(x + 0.5D, chao.getY() + 1.8D, z + 0.5D);
            if (w.rayTraceBlocks(olhoJogador, olhoEntidade, false, true, false) != null) continue; // parede no meio

            EntityObservador e = new EntityObservador(w);
            e.setTipo(EntityObservador.TIPO_CASA);
            e.setVidaMax(Config.CASA_DURACAO);
            e.setLocationAndAngles(x + 0.5D, chao.getY(), z + 0.5D, 0.0F, 0.0F);
            w.spawnEntity(e);
            return true;
        }
        return false;
    }

    private static int contar(World w, AxisAlignedBB caixa, int tipo) {
        int n = 0;
        List<EntityObservador> lista = w.getEntitiesWithinAABB(EntityObservador.class, caixa);
        for (EntityObservador e : lista) {
            if (e.getTipo() == tipo) n++;
        }
        return n;
    }

    // ------------------------------------------------------------------ chat

    /** Chance (%) de ele chamar o jogador pelo nome no chat, 1,5 a 4 s depois. Respeita fase e cooldown. */
    public static void chamarNome(EntityPlayer p, int chance) {
        falar(p, chance, false);
    }

    /** Versao pro comando de teste: ignora fase, chance e cooldown. */
    public static void chamarNomeForcado(EntityPlayer p) {
        falar(p, 100, true);
    }

    private static void falar(final EntityPlayer p, int chance, boolean ignorarRegras) {
        if (!(p instanceof EntityPlayerMP)) return;
        World w = p.world;
        Random r = p.getRNG();
        long agora = w.getTotalWorldTime();

        if (!ignorarRegras) {
            if (Fase.de(w) < 1) return;
            if (r.nextInt(100) >= chance) return;
            Long ult = ULTIMA_FALA.get(p.getUniqueID());
            if (ult != null && agora - ult.longValue() < Config.CHAT_COOLDOWN) return;
        }
        ULTIMA_FALA.put(p.getUniqueID(), agora);

        final String texto = FALAS[r.nextInt(FALAS.length)].replace("%s", p.getName());
        Diretor.agendar(25 + r.nextInt(60), new Runnable() {
            @Override
            public void run() {
                if (!p.isDead) {
                    p.sendMessage(new TextComponentString("<" + Config.NOME_NO_CHAT + "> " + texto));
                }
            }
        });
    }

    public static void limparFalas() {
        ULTIMA_FALA.clear();
    }

    // ------------------------------------------------------------------ sons

    /** Tocou quando o jogador percebe o Observador pela primeira vez. */
    public static void somVisto(EntityPlayer p) {
        if (Fase.de(p.world) < 1) return;
        tocarEm(p, SoundEvents.AMBIENT_CAVE, p.posX, p.posY, p.posZ, 1.0F, 0.6F);
    }

    public static void somPerturbador(EntityPlayer p, int fase) {
        Random r = p.getRNG();
        switch (r.nextInt(fase >= 2 ? 6 : 4)) {
            case 0: passosAtras(p); break;
            case 1: perto(p, SoundEvents.AMBIENT_CAVE, 1.0F, 0.7F); break;
            case 2: porta(p); break;
            case 3: perto(p, SoundEvents.ENTITY_ENDERMEN_AMBIENT, 0.5F, 0.5F); break;
            case 4: perto(p, SoundEvents.ENTITY_WITHER_AMBIENT, 0.35F, 0.55F); break;
            default: perto(p, SoundEvents.ENTITY_ENDERMEN_STARE, 0.6F, 0.5F); break;
        }
    }

    /** Passos que vem de tras, chegam perto... e param. */
    private static void passosAtras(final EntityPlayer p) {
        World w = p.world;
        Random r = p.getRNG();
        BlockPos sob = p.getPosition().down();
        IBlockState estado = w.getBlockState(sob);
        SoundType tipo = estado.getBlock().getSoundType(estado, w, sob, p);
        final SoundEvent passo = tipo.getStepSound();
        double ang = Math.toRadians(p.rotationYaw + 180.0D + r.nextInt(61) - 30);

        for (int i = 0; i < 6; i++) {
            final double dist = 9.0D - i * 1.2D;
            final double x = p.posX - Math.sin(ang) * dist;
            final double z = p.posZ + Math.cos(ang) * dist;
            final double y = p.posY;
            Diretor.agendar(i * 9, new Runnable() {
                @Override
                public void run() {
                    if (!p.isDead) tocarEm(p, passo, x, y, z, 0.8F, 0.9F);
                }
            });
        }
    }

    /** Porta abrindo e fechando em algum lugar perto. */
    private static void porta(final EntityPlayer p) {
        Random r = p.getRNG();
        double ang = r.nextDouble() * Math.PI * 2.0D;
        double d = 6 + r.nextInt(6);
        final double x = p.posX - Math.sin(ang) * d;
        final double z = p.posZ + Math.cos(ang) * d;
        final double y = p.posY;
        tocarEm(p, SoundEvents.BLOCK_WOODEN_DOOR_OPEN, x, y, z, 1.0F, 0.9F);
        Diretor.agendar(35, new Runnable() {
            @Override
            public void run() {
                if (!p.isDead) tocarEm(p, SoundEvents.BLOCK_WOODEN_DOOR_CLOSE, x, y, z, 1.0F, 0.9F);
            }
        });
    }

    /** Toca um som num ponto aleatorio de 6 a 12 blocos em volta (da pra sentir a direcao). */
    private static void perto(EntityPlayer p, SoundEvent som, float vol, float pitch) {
        Random r = p.getRNG();
        double ang = r.nextDouble() * Math.PI * 2.0D;
        double d = 6 + r.nextInt(7);
        tocarEm(p, som, p.posX - Math.sin(ang) * d, p.posY, p.posZ + Math.cos(ang) * d, vol, pitch);
    }

    /** Manda o som so pra esse jogador, na categoria "ambiente". */
    public static void tocarEm(EntityPlayer p, SoundEvent som, double x, double y, double z, float vol, float pitch) {
        if (p instanceof EntityPlayerMP) {
            ((EntityPlayerMP) p).connection.sendPacket(
                    new SPacketSoundEffect(som, SoundCategory.AMBIENT, x, y, z, vol, pitch));
        }
    }
}
