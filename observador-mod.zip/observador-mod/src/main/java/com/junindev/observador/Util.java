package com.junindev.observador;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public final class Util {
    private Util() {}

    /** O jogador esta olhando pra esse alvo? cosMin: 0.97 = cone estreito (~14 graus), 0.8 = cone largo (~37). */
    public static boolean estaOlhando(EntityPlayer p, Entity alvo, double cosMin) {
        Vec3d olhar = p.getLook(1.0F).normalize();
        Vec3d ate = new Vec3d(
                alvo.posX - p.posX,
                (alvo.posY + alvo.getEyeHeight()) - (p.posY + p.getEyeHeight()),
                alvo.posZ - p.posZ);
        double dist = ate.lengthVector();
        if (dist < 1.0E-4D) return true;
        ate = ate.scale(1.0D / dist);
        return olhar.dotProduct(ate) > cosMin && p.canEntityBeSeen(alvo);
    }

    public static EntityPlayer jogadorMaisProximo(World w, Entity de, double max) {
        EntityPlayer melhor = null;
        double melhorD = max * max;
        for (EntityPlayer p : w.playerEntities) {
            if (p.isSpectator()) continue;
            double d = p.getDistanceSq(de);
            if (d < melhorD) {
                melhorD = d;
                melhor = p;
            }
        }
        return melhor;
    }

    /** Procura um chao com 3 blocos livres em cima, perto da altura yCentro. Retorna a posicao dos PES, ou null. */
    public static BlockPos acharChao(World w, int x, int z, int yCentro, int faixa) {
        int yc = Math.max(0, Math.min(255, yCentro));
        if (!w.isBlockLoaded(new BlockPos(x, yc, z))) return null;
        int yMax = Math.min(250, yCentro + faixa);
        int yMin = Math.max(2, yCentro - faixa);
        for (int y = yMax; y >= yMin; y--) {
            BlockPos pos = new BlockPos(x, y, z);
            if (livre(w, pos) && livre(w, pos.up()) && livre(w, pos.up(2)) && w.getBlockState(pos.down()).isTopSolid()) {
                return pos;
            }
        }
        return null;
    }

    private static boolean livre(World w, BlockPos p) {
        IBlockState s = w.getBlockState(p);
        return !s.getMaterial().blocksMovement() && !s.getMaterial().isLiquid();
    }

    /** Vira corpo e cabeca da entidade pra encarar o alvo. */
    public static void virarPara(EntityLiving e, Entity alvo) {
        double dx = alvo.posX - e.posX;
        double dz = alvo.posZ - e.posZ;
        double dy = (alvo.posY + alvo.getEyeHeight()) - (e.posY + e.getEyeHeight());
        float yaw = (float) (Math.atan2(dz, dx) * 180.0D / Math.PI) - 90.0F;
        float pitch = (float) (-(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0D / Math.PI));
        e.rotationYaw = yaw;
        e.rotationYawHead = yaw;
        e.renderYawOffset = yaw;
        e.rotationPitch = pitch;
    }
}
